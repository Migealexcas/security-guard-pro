// App.js — SecurityGuard Pro · Expo React Native
import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar, Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

import { COLORS, INITIAL_APPS, INITIAL_THREATS } from './src/data';
import HomeScreen    from './src/screens/HomeScreen';
import AppsScreen    from './src/screens/AppsScreen';
import PermisosScreen from './src/screens/PermisosScreen';
import ThreatsScreen from './src/screens/ThreatsScreen';
import CleaningScreen from './src/screens/CleaningScreen';

// ── Toast ────────────────────────────────────────────────────────────────────
function ToastBanner({ toasts }) {
  if (toasts.length === 0) return null;
  const t = toasts[0];
  const bg = t.type === 'success' ? 'rgba(0,230,118,0.15)'
    : t.type === 'warning' ? 'rgba(255,179,0,0.15)'
    : 'rgba(0,198,255,0.12)';
  const border = t.type === 'success' ? 'rgba(0,230,118,0.3)'
    : t.type === 'warning' ? 'rgba(255,179,0,0.3)'
    : 'rgba(0,198,255,0.25)';
  const color = t.type === 'success' ? COLORS.success
    : t.type === 'warning' ? COLORS.warn : COLORS.primary;
  const icon = t.type === 'success' ? '✓' : t.type === 'warning' ? '⚠' : 'ℹ';
  return (
    <View style={[styles.toast, { backgroundColor: bg, borderColor: border }]}>
      <Text style={[styles.toastIcon, { color }]}>{icon}</Text>
      <Text style={[styles.toastText, { color }]}>{t.message}</Text>
    </View>
  );
}

// ── Nav tabs ─────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'home',     icon: '🏠', label: 'Inicio'    },
  { id: 'apps',     icon: '📱', label: 'Apps'      },
  { id: 'permisos', icon: '🔐', label: 'Permisos'  },
  { id: 'threats',  icon: '⚠️', label: 'Amenazas'  },
  { id: 'cleaning', icon: '🧹', label: 'Limpiar'   },
];

// ── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab]         = useState('home');
  const [apps, setApps]       = useState(INITIAL_APPS);
  const [threats, setThreats] = useState(INITIAL_THREATS);
  const [toasts, setToasts]   = useState([]);
  const [secScore, setSecScore]     = useState(82);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProg, setScanProg]     = useState(0);
  const [cleaningType, setCleaningType] = useState(null);
  const [cleanProg, setCleanProg]       = useState(0);
  const [cleanedMB, setCleanedMB]       = useState(3091);

  // ── Toast helper ──
  const addToast = useCallback((message, type = 'info') => {
    const id = Date.now();
    setToasts(p => [...p, { id, message, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 2800);
  }, []);

  // ── Permission toggles ──
  const togglePerm = useCallback((appId, permName) => {
    setApps(prev => prev.map(app => {
      if (app.id !== appId) return app;
      const perms = app.allPermissions.map(p =>
        p.name === permName ? { ...p, enabled: !p.enabled } : p
      );
      return { ...app, allPermissions: perms, dangerousPerms: perms.filter(p => p.enabled && p.category === 'dangerous').length };
    }));
    addToast('Permiso actualizado', 'success');
  }, [addToast]);

  const enableAll = useCallback((appId) => {
    setApps(prev => prev.map(app => {
      if (app.id !== appId) return app;
      const perms = app.allPermissions.map(p => ({ ...p, enabled: true }));
      return { ...app, allPermissions: perms, dangerousPerms: perms.filter(p => p.enabled && p.category === 'dangerous').length };
    }));
    addToast('Todos los permisos habilitados', 'success');
  }, [addToast]);

  const revokeDangerous = useCallback((appId) => {
    setApps(prev => prev.map(app => {
      if (app.id !== appId) return app;
      const perms = app.allPermissions.map(p => p.category === 'dangerous' ? { ...p, enabled: false } : p);
      return { ...app, allPermissions: perms, dangerousPerms: 0 };
    }));
    addToast('Permisos peligrosos revocados', 'warning');
  }, [addToast]);

  // ── Scan ──
  const startScan = useCallback(() => {
    if (isScanning) return;
    setIsScanning(true); setScanProg(0);
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random() * 18;
      if (p >= 100) {
        p = 100; clearInterval(iv);
        const total = apps.reduce((s, a) => s + a.dangerousPerms, 0);
        setSecScore(Math.max(30, 100 - total * 5));
        setScanProg(100);
        addToast(`Escaneo completado — ${apps.length} apps analizadas`, 'success');
        setTimeout(() => { setIsScanning(false); setScanProg(0); }, 1200);
      } else { setScanProg(Math.floor(p)); }
    }, 180);
  }, [isScanning, apps, addToast]);

  // ── Resolve threat ──
  const resolveThreat = useCallback((id, appName) => {
    setThreats(p => p.filter(t => t.id !== id));
    setApps(prev => prev.map(app => {
      if (app.name !== appName) return app;
      const perms = app.allPermissions.map(p => p.category === 'dangerous' ? { ...p, enabled: false } : p);
      return { ...app, allPermissions: perms, dangerousPerms: 0 };
    }));
    addToast(`Amenaza de ${appName} resuelta`, 'success');
  }, [addToast]);

  // ── Cleaning ──
  const startCleaning = useCallback((type, mb) => {
    if (cleaningType) return;
    setCleaningType(type); setCleanProg(0);
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random() * 20;
      if (p >= 100) {
        p = 100; clearInterval(iv);
        setCleanProg(100);
        setCleanedMB(prev => prev + mb);
        addToast(`${mb} MB liberados`, 'success');
        setTimeout(() => { setCleaningType(null); setCleanProg(0); }, 1000);
      } else { setCleanProg(Math.floor(p)); }
    }, 120);
  }, [cleaningType, addToast]);

  // ── Render current screen ──
  const renderScreen = () => {
    switch (tab) {
      case 'home':
        return <HomeScreen
          apps={apps} threats={threats} secScore={secScore}
          isScanning={isScanning} scanProg={scanProg}
          onScan={startScan} onResolve={resolveThreat}
          onNavigate={setTab}
        />;
      case 'apps':
        return <AppsScreen
          apps={apps}
          onTogglePerm={togglePerm}
          onEnableAll={enableAll}
          onRevokeDangerous={revokeDangerous}
        />;
      case 'permisos':
        return <PermisosScreen apps={apps} onTogglePerm={togglePerm} />;
      case 'threats':
        return <ThreatsScreen threats={threats} onResolve={resolveThreat} />;
      case 'cleaning':
        return <CleaningScreen
          cleaningType={cleaningType} cleanProg={cleanProg}
          cleanedMB={cleanedMB} onClean={startCleaning}
        />;
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.surface} />

      {/* Top bar */}
      <LinearGradient
        colors={[COLORS.surface, COLORS.surface]}
        style={styles.topBar}
      >
        <View>
          <Text style={styles.appTitle}>SecurityGuard Pro</Text>
          <Text style={styles.appSub}>Control total de seguridad</Text>
        </View>
        <View style={styles.topActions}>
          <TouchableOpacity style={styles.iconBtn}>
            <Text style={styles.iconBtnTxt}>🔔</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn}>
            <Text style={styles.iconBtnTxt}>⚙️</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* Toast */}
      <View style={styles.toastWrap} pointerEvents="none">
        <ToastBanner toasts={toasts} />
      </View>

      {/* Screen content */}
      <View style={styles.screenWrap}>
        {renderScreen()}
      </View>

      {/* Bottom nav */}
      <View style={styles.bottomNav}>
        {TABS.map(t => {
          const active = tab === t.id;
          return (
            <TouchableOpacity
              key={t.id}
              style={styles.navItem}
              onPress={() => setTab(t.id)}
              activeOpacity={0.7}
            >
              <View style={[styles.navPill, active && styles.navPillActive]}>
                <Text style={styles.navIcon}>{t.icon}</Text>
              </View>
              <Text style={[styles.navLabel, active && styles.navLabelActive]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  topBar: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: COLORS.cardBorder,
  },
  appTitle: {
    fontSize: 20, fontWeight: '700', color: COLORS.primary,
  },
  appSub: { fontSize: 11, color: COLORS.textSub, marginTop: 1 },
  topActions: { flexDirection: 'row', gap: 8 },
  iconBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: COLORS.card,
    alignItems: 'center', justifyContent: 'center',
  },
  iconBtnTxt: { fontSize: 17 },
  toastWrap: {
    position: 'absolute', top: 80, left: 16, right: 16, zIndex: 999,
  },
  toast: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 12, padding: 12, borderWidth: 1,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 8,
  },
  toastIcon: { fontSize: 16, fontWeight: '700' },
  toastText: { fontSize: 13, fontWeight: '600', flex: 1 },
  screenWrap: { flex: 1 },
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: COLORS.surface,
    borderTopWidth: 1, borderTopColor: COLORS.cardBorder,
    paddingBottom: 4,
  },
  navItem: {
    flex: 1, alignItems: 'center', paddingTop: 8, paddingBottom: 4, gap: 2,
  },
  navPill: {
    width: 48, height: 32, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  navPillActive: { backgroundColor: 'rgba(0,198,255,0.15)' },
  navIcon: { fontSize: 19 },
  navLabel: { fontSize: 10, color: COLORS.textMuted, fontWeight: '600' },
  navLabelActive: { color: COLORS.primary },
});
