// src/screens/HomeScreen.js
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle } from 'react-native-svg';
import { COLORS } from '../data';

function ScoreRing({ score }) {
  const r = 56;
  const circ = 2 * Math.PI * r;
  const color = score >= 80 ? COLORS.success : score >= 60 ? COLORS.warn : COLORS.danger;
  const label = score >= 80 ? 'Excelente' : score >= 60 ? 'Moderado' : 'En Riesgo';
  const filled = (score / 100) * circ;

  return (
    <View style={styles.ringWrap}>
      <Svg width={130} height={130} style={{ transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={65} cy={65} r={r} fill="none" stroke="#1E2D45" strokeWidth={10} />
        <Circle
          cx={65} cy={65} r={r} fill="none"
          stroke={color} strokeWidth={10}
          strokeDasharray={`${filled} ${circ}`}
          strokeLinecap="round"
        />
      </Svg>
      <View style={styles.ringCenter}>
        <Text style={[styles.ringNum, { color }]}>{score}</Text>
        <Text style={styles.ringLabel}>{label}</Text>
      </View>
    </View>
  );
}

export default function HomeScreen({ apps, threats, secScore, isScanning, scanProg, onScan, onResolve, onNavigate }) {
  const totalPerms = apps.reduce((s, a) => s + a.permissions, 0);
  const totalDangerous = apps.reduce((s, a) => s + a.dangerousPerms, 0);
  const cleanedGB = (3091 / 1024).toFixed(1);

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

      {/* Score card */}
      <View style={styles.card}>
        <Text style={styles.sectionLabel}>PUNTUACIÓN DE SEGURIDAD</Text>
        <ScoreRing score={secScore} />

        {isScanning && (
          <View style={styles.scanningBox}>
            <View style={styles.scanRow}>
              <Text style={styles.scanText}>Analizando sistema...</Text>
              <Text style={styles.scanPct}>{scanProg}%</Text>
            </View>
            <View style={styles.progTrack}>
              <LinearGradient
                colors={[COLORS.primary, COLORS.purple]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={[styles.progFill, { width: `${scanProg}%` }]}
              />
            </View>
            <Text style={styles.scanSub}>Permisos • Amenazas • Integridad</Text>
          </View>
        )}

        <TouchableOpacity onPress={onScan} disabled={isScanning} activeOpacity={0.8}>
          <LinearGradient
            colors={isScanning ? ['#1A3050', '#1A3050'] : [COLORS.primary, COLORS.primaryDark]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.scanBtn}
          >
            <Text style={styles.scanBtnText}>
              {isScanning ? `🔄  Escaneando... ${scanProg}%` : '⚡  Escanear Ahora'}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Stats grid */}
      <View style={styles.statGrid}>
        {[
          { val: apps.length,     lbl: 'Apps monitoreadas', color: COLORS.primary },
          { val: totalPerms,      lbl: 'Permisos totales',  color: COLORS.warn    },
          { val: totalDangerous,  lbl: 'Peligrosos activos',color: COLORS.danger  },
          { val: `${cleanedGB}G`, lbl: 'Espacio liberado',  color: COLORS.success },
        ].map((s, i) => (
          <View key={i} style={styles.statCard}>
            <Text style={[styles.statVal, { color: s.color }]}>{s.val}</Text>
            <Text style={styles.statLbl}>{s.lbl}</Text>
          </View>
        ))}
      </View>

      {/* Quick actions */}
      <Text style={styles.sectionLabel}>ACCIONES RÁPIDAS</Text>
      <View style={styles.quickGrid}>
        {[
          { icon: '📱', label: 'Ver Apps',    dot: COLORS.primary, tab: 'apps'     },
          { icon: '🔐', label: 'Permisos',    dot: COLORS.success, tab: 'permisos' },
          { icon: '⚠️', label: `Amenazas ${threats.length > 0 ? `(${threats.length})` : ''}`, dot: COLORS.danger, tab: 'threats' },
          { icon: '🧹', label: 'Limpiar',     dot: COLORS.purple,  tab: 'cleaning' },
        ].map((q, i) => (
          <TouchableOpacity key={i} style={styles.quickBtn} onPress={() => onNavigate(q.tab)} activeOpacity={0.7}>
            <View style={[styles.quickDot, { backgroundColor: q.dot }]} />
            <Text style={styles.quickIcon}>{q.icon}</Text>
            <Text style={styles.quickLabel}>{q.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Recent alerts */}
      {threats.length > 0 && (
        <>
          <Text style={styles.sectionLabel}>⚠️ ALERTAS RECIENTES</Text>
          {threats.slice(0, 2).map(t => (
            <View key={t.id} style={styles.alertCard}>
              <View style={styles.alertRow}>
                <Text style={styles.alertApp}>{t.app} — {t.type}</Text>
                <TouchableOpacity style={styles.resolveBtn} onPress={() => onResolve(t.id, t.app)}>
                  <Text style={styles.resolveTxt}>Resolver</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.alertDesc}>{t.desc}</Text>
            </View>
          ))}
        </>
      )}

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 12, paddingBottom: 24, gap: 12 },
  card: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    padding: 16,
    gap: 12,
  },
  sectionLabel: {
    fontSize: 11, fontWeight: '700', color: COLORS.textSub,
    letterSpacing: 1, marginBottom: 4, marginTop: 4,
  },
  ringWrap: { alignItems: 'center', justifyContent: 'center', height: 140 },
  ringCenter: { position: 'absolute', alignItems: 'center' },
  ringNum: { fontSize: 38, fontWeight: '700', lineHeight: 42 },
  ringLabel: { fontSize: 11, color: COLORS.textSub, marginTop: 2 },
  scanningBox: { gap: 6 },
  scanRow: { flexDirection: 'row', justifyContent: 'space-between' },
  scanText: { fontSize: 12, color: COLORS.primary },
  scanPct: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  progTrack: { height: 6, backgroundColor: COLORS.surface, borderRadius: 6, overflow: 'hidden' },
  progFill: { height: 6, borderRadius: 6 },
  scanSub: { fontSize: 11, color: COLORS.textSub },
  scanBtn: { borderRadius: 14, padding: 14, alignItems: 'center' },
  scanBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  statGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard: {
    flex: 1, minWidth: '45%',
    backgroundColor: COLORS.surface,
    borderRadius: 16, padding: 14, gap: 4,
  },
  statVal: { fontSize: 28, fontWeight: '700' },
  statLbl: { fontSize: 11, color: COLORS.textSub },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  quickBtn: {
    flex: 1, minWidth: '45%',
    backgroundColor: COLORS.surface,
    borderRadius: 14, borderWidth: 1, borderColor: COLORS.cardBorder,
    padding: 14, flexDirection: 'row', alignItems: 'center', gap: 8,
  },
  quickDot: { width: 10, height: 10, borderRadius: 5 },
  quickIcon: { fontSize: 16 },
  quickLabel: { fontSize: 13, fontWeight: '600', color: COLORS.text, flex: 1 },
  alertCard: {
    backgroundColor: 'rgba(255,71,87,0.07)',
    borderWidth: 1, borderColor: 'rgba(255,71,87,0.2)',
    borderRadius: 14, padding: 12, gap: 6,
  },
  alertRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  alertApp: { fontSize: 13, fontWeight: '700', color: COLORS.text, flex: 1 },
  alertDesc: { fontSize: 11, color: COLORS.textSub },
  resolveBtn: {
    paddingVertical: 6, paddingHorizontal: 14,
    borderRadius: 20, borderWidth: 1,
    borderColor: 'rgba(0,198,255,0.4)',
    backgroundColor: 'rgba(0,198,255,0.1)',
  },
  resolveTxt: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
});
