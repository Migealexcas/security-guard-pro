// src/screens/AppsScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { COLORS } from '../data';

function PermBtn({ perm, onPress }) {
  const bg = perm.enabled
    ? perm.category === 'dangerous'
      ? { bg: 'rgba(255,71,87,0.12)', border: 'rgba(255,71,87,0.3)', color: COLORS.danger }
      : { bg: 'rgba(0,230,118,0.10)', border: 'rgba(0,230,118,0.25)', color: COLORS.success }
    : { bg: 'rgba(138,155,181,0.07)', border: 'rgba(138,155,181,0.15)', color: COLORS.textMuted };

  return (
    <TouchableOpacity
      style={[styles.permBtn, { backgroundColor: bg.bg, borderColor: bg.border }]}
      onPress={onPress} activeOpacity={0.7}
    >
      <Text style={styles.permIcon}>{perm.icon}</Text>
      <Text style={[styles.permName, { color: bg.color }]} numberOfLines={1}>{perm.name}</Text>
      <Text style={[styles.permState, { color: bg.color }]}>{perm.enabled ? 'ON' : 'OFF'}</Text>
    </TouchableOpacity>
  );
}

export default function AppsScreen({ apps, onTogglePerm, onEnableAll, onRevokeDangerous }) {
  const [expanded, setExpanded] = useState(null);

  const getBadgeStyle = (n) =>
    n > 4 ? styles.badgeDanger : n > 2 ? styles.badgeWarn : styles.badgeOk;

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionLabel}>📱 {apps.length} APLICACIONES</Text>

      {apps.map(app => (
        <TouchableOpacity
          key={app.id}
          style={styles.appCard}
          onPress={() => setExpanded(expanded === app.id ? null : app.id)}
          activeOpacity={0.8}
        >
          {/* Row */}
          <View style={styles.appRow}>
            <View style={styles.appIconWrap}>
              <Text style={styles.appIcon}>{app.icon}</Text>
            </View>
            <View style={styles.appInfo}>
              <Text style={styles.appName}>{app.name}</Text>
              <Text style={styles.appPkg} numberOfLines={1}>{app.package}</Text>
              <View style={styles.appMeta}>
                <Text style={[styles.metaTag, { color: COLORS.primary }]}>v{app.version}</Text>
                <Text style={[styles.metaTag, { color: COLORS.warn }]}>{app.size}MB</Text>
                <Text style={[styles.metaTag, { color: COLORS.success }]}>⭐{app.rating}</Text>
              </View>
            </View>
            <View style={styles.permCountWrap}>
              <Text style={styles.permCountNum}>{app.permissions}</Text>
              <Text style={styles.permCountLbl}>perms</Text>
            </View>
            <View style={[styles.badge, getBadgeStyle(app.dangerousPerms)]}>
              <Text style={styles.badgeText}>{app.dangerousPerms}</Text>
            </View>
          </View>

          {/* Expanded */}
          {expanded === app.id && (
            <View style={styles.expanded}>
              <View style={styles.divider} />
              <View style={styles.actionRow}>
                <TouchableOpacity
                  style={styles.actionBtnEnable}
                  onPress={() => onEnableAll(app.id)}
                >
                  <Text style={styles.actionTxtEnable}>✓ Habilitar Todo</Text>
                </TouchableOpacity>
                {app.dangerousPerms > 0 && (
                  <TouchableOpacity
                    style={styles.actionBtnRevoke}
                    onPress={() => onRevokeDangerous(app.id)}
                  >
                    <Text style={styles.actionTxtRevoke}>✕ Revocar Peligrosos</Text>
                  </TouchableOpacity>
                )}
              </View>
              <View style={styles.permGrid}>
                {app.allPermissions.map((p, i) => (
                  <PermBtn
                    key={i} perm={p}
                    onPress={() => onTogglePerm(app.id, p.name)}
                  />
                ))}
              </View>
            </View>
          )}
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 12, paddingBottom: 24, gap: 10 },
  sectionLabel: {
    fontSize: 11, fontWeight: '700', color: COLORS.textSub,
    letterSpacing: 1, marginBottom: 4,
  },
  appCard: {
    backgroundColor: COLORS.card,
    borderRadius: 16, borderWidth: 1, borderColor: COLORS.cardBorder,
    overflow: 'hidden',
  },
  appRow: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  appIconWrap: {
    width: 48, height: 48, borderRadius: 14,
    backgroundColor: COLORS.surface,
    alignItems: 'center', justifyContent: 'center',
  },
  appIcon: { fontSize: 26 },
  appInfo: { flex: 1, minWidth: 0 },
  appName: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  appPkg: { fontSize: 11, color: COLORS.textSub, marginTop: 2 },
  appMeta: { flexDirection: 'row', gap: 8, marginTop: 4 },
  metaTag: { fontSize: 11 },
  permCountWrap: { alignItems: 'center' },
  permCountNum: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  permCountLbl: { fontSize: 10, color: COLORS.textSub },
  badge: {
    width: 38, height: 38, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1,
  },
  badgeDanger: { backgroundColor: 'rgba(255,71,87,0.15)', borderColor: 'rgba(255,71,87,0.25)' },
  badgeWarn:   { backgroundColor: 'rgba(255,179,0,0.15)',  borderColor: 'rgba(255,179,0,0.25)'  },
  badgeOk:     { backgroundColor: 'rgba(0,230,118,0.15)',  borderColor: 'rgba(0,230,118,0.25)'  },
  badgeText: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  expanded: { paddingHorizontal: 14, paddingBottom: 14 },
  divider: { height: 1, backgroundColor: COLORS.cardBorder, marginBottom: 12 },
  actionRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  actionBtnEnable: {
    flex: 1, padding: 8, borderRadius: 10, alignItems: 'center',
    backgroundColor: 'rgba(0,230,118,0.10)',
    borderWidth: 1, borderColor: 'rgba(0,230,118,0.3)',
  },
  actionBtnRevoke: {
    flex: 1, padding: 8, borderRadius: 10, alignItems: 'center',
    backgroundColor: 'rgba(255,71,87,0.10)',
    borderWidth: 1, borderColor: 'rgba(255,71,87,0.3)',
  },
  actionTxtEnable: { fontSize: 12, fontWeight: '700', color: COLORS.success },
  actionTxtRevoke: { fontSize: 12, fontWeight: '700', color: COLORS.danger },
  permGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  permBtn: {
    width: '30%', borderRadius: 10, borderWidth: 1,
    padding: 8, alignItems: 'center', gap: 2,
  },
  permIcon: { fontSize: 18 },
  permName: { fontSize: 10, fontWeight: '600', textAlign: 'center' },
  permState: { fontSize: 10, fontWeight: '700' },
});
