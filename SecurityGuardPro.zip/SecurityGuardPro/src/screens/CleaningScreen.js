// src/screens/CleaningScreen.js
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS } from '../data';

const CLEANERS = [
  {
    type: 'cache', label: 'Caché de Apps',
    sub: 'Datos temporales de aplicaciones',
    mb: 1200, colors: [COLORS.primary, COLORS.primaryDark],
  },
  {
    type: 'temp', label: 'Archivos Temporales',
    sub: 'Descargas y archivos huérfanos',
    mb: 890, colors: [COLORS.success, '#00B05A'],
  },
  {
    type: 'optimize', label: 'Análisis Profundo',
    sub: 'Optimización completa del sistema',
    mb: 2100, colors: [COLORS.purple, '#7B1FA2'],
  },
];

export default function CleaningScreen({ cleaningType, cleanProg, cleanedMB, onClean }) {
  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionLabel}>🧹 CENTRO DE LIMPIEZA</Text>

      {CLEANERS.map(c => (
        <View key={c.type} style={styles.card}>
          <View style={styles.cardTop}>
            <Text style={styles.cardTitle}>{c.label}</Text>
            <Text style={styles.cardSub}>{c.sub}</Text>
            <Text style={styles.cardSpace}>Hasta {(c.mb / 1024).toFixed(1)} GB disponibles</Text>
          </View>

          {cleaningType === c.type && (
            <View style={styles.progWrap}>
              <View style={styles.progRow}>
                <Text style={styles.progLbl}>Limpiando...</Text>
                <Text style={styles.progPct}>{cleanProg}%</Text>
              </View>
              <View style={styles.progTrack}>
                <LinearGradient
                  colors={c.colors}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={[styles.progFill, { width: `${cleanProg}%` }]}
                />
              </View>
            </View>
          )}

          <TouchableOpacity
            disabled={!!cleaningType}
            onPress={() => onClean(c.type, c.mb)}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={cleaningType ? ['#1A2235', '#1A2235'] : c.colors}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={[styles.cleanBtn, cleaningType && styles.cleanBtnDisabled]}
            >
              <Text style={styles.cleanBtnText}>
                {cleaningType === c.type ? 'Limpiando...' : 'Iniciar Limpieza'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ))}

      {cleanedMB > 0 && (
        <View style={styles.resultCard}>
          <Text style={styles.resultIcon}>✅</Text>
          <View>
            <Text style={styles.resultTitle}>Limpieza Completada</Text>
            <Text style={styles.resultSub}>
              Total liberado:{' '}
              <Text style={styles.resultVal}>{(cleanedMB / 1024).toFixed(2)} GB</Text>
            </Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 12, paddingBottom: 24, gap: 12 },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: COLORS.textSub, letterSpacing: 1, marginBottom: 4 },
  card: {
    backgroundColor: COLORS.card, borderRadius: 16,
    borderWidth: 1, borderColor: COLORS.cardBorder, padding: 16, gap: 12,
  },
  cardTop: { gap: 2 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  cardSub: { fontSize: 12, color: COLORS.textSub },
  cardSpace: { fontSize: 11, color: COLORS.primary, marginTop: 2 },
  progWrap: { gap: 6 },
  progRow: { flexDirection: 'row', justifyContent: 'space-between' },
  progLbl: { fontSize: 12, color: COLORS.textSub },
  progPct: { fontSize: 12, fontWeight: '700', color: COLORS.text },
  progTrack: { height: 6, backgroundColor: COLORS.surface, borderRadius: 6, overflow: 'hidden' },
  progFill: { height: 6, borderRadius: 6 },
  cleanBtn: { borderRadius: 12, padding: 14, alignItems: 'center' },
  cleanBtnDisabled: { opacity: 0.5 },
  cleanBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  resultCard: {
    flexDirection: 'row', gap: 14, alignItems: 'center',
    backgroundColor: 'rgba(0,230,118,0.07)',
    borderWidth: 1, borderColor: 'rgba(0,230,118,0.2)',
    borderRadius: 16, padding: 16,
  },
  resultIcon: { fontSize: 36 },
  resultTitle: { fontSize: 15, fontWeight: '700', color: COLORS.success },
  resultSub: { fontSize: 13, color: COLORS.textSub, marginTop: 2 },
  resultVal: { color: COLORS.success, fontWeight: '700' },
});
