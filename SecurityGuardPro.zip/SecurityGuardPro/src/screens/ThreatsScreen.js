// src/screens/ThreatsScreen.js
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS } from '../data';

export default function ThreatsScreen({ threats, onResolve }) {
  if (threats.length === 0) {
    return (
      <View style={styles.emptyWrap}>
        <Text style={styles.emptyIcon}>✅</Text>
        <Text style={styles.emptyTitle}>Sin amenazas</Text>
        <Text style={styles.emptySub}>Tu dispositivo está completamente protegido</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionLabel}>⚠️ {threats.length} AMENAZA{threats.length !== 1 ? 'S' : ''} DETECTADA{threats.length !== 1 ? 'S' : ''}</Text>
      {threats.map(t => (
        <View key={t.id} style={[styles.card, t.severity === 'high' ? styles.cardHigh : styles.cardMed]}>
          <View style={styles.header}>
            <Text style={styles.appName}>{t.app}</Text>
            <View style={[styles.sevBadge, t.severity === 'high' ? styles.sevHigh : styles.sevMed]}>
              <Text style={[styles.sevText, { color: t.severity === 'high' ? COLORS.danger : COLORS.warn }]}>
                {t.severity === 'high' ? 'ALTO' : 'MEDIO'}
              </Text>
            </View>
          </View>
          <Text style={styles.type}>{t.type}</Text>
          <Text style={styles.desc}>{t.desc}</Text>
          <TouchableOpacity style={styles.resolveBtn} onPress={() => onResolve(t.id, t.app)} activeOpacity={0.8}>
            <Text style={styles.resolveTxt}>{t.action} →</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 12, paddingBottom: 24, gap: 12 },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: COLORS.textSub, letterSpacing: 1, marginBottom: 4 },
  card: { borderRadius: 16, padding: 16, borderLeftWidth: 4, gap: 8 },
  cardHigh: { backgroundColor: 'rgba(255,71,87,0.07)', borderLeftColor: COLORS.danger },
  cardMed:  { backgroundColor: 'rgba(255,179,0,0.07)',  borderLeftColor: COLORS.warn   },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  appName: { fontSize: 16, fontWeight: '700', color: COLORS.text, flex: 1 },
  sevBadge: { paddingVertical: 3, paddingHorizontal: 10, borderRadius: 20 },
  sevHigh: { backgroundColor: 'rgba(255,71,87,0.2)' },
  sevMed:  { backgroundColor: 'rgba(255,179,0,0.2)'  },
  sevText: { fontSize: 10, fontWeight: '700' },
  type: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  desc: { fontSize: 12, color: COLORS.textSub, lineHeight: 18 },
  resolveBtn: {
    alignSelf: 'flex-end',
    paddingVertical: 8, paddingHorizontal: 18,
    borderRadius: 20, borderWidth: 1,
    borderColor: 'rgba(0,198,255,0.4)',
    backgroundColor: 'rgba(0,198,255,0.1)',
  },
  resolveTxt: { fontSize: 13, fontWeight: '700', color: COLORS.primary },
  emptyWrap: { flex: 1, backgroundColor: COLORS.bg, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 32 },
  emptyIcon: { fontSize: 64 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: COLORS.text },
  emptySub: { fontSize: 14, color: COLORS.textSub, textAlign: 'center' },
});
