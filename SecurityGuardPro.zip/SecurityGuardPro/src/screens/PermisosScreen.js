// src/screens/PermisosScreen.js
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS } from '../data';

export default function PermisosScreen({ apps, onTogglePerm }) {
  const getBadgeStyle = (n) =>
    n > 4 ? { bg: 'rgba(255,71,87,0.15)', border: 'rgba(255,71,87,0.25)', color: COLORS.danger }
    : n > 2 ? { bg: 'rgba(255,179,0,0.15)',  border: 'rgba(255,179,0,0.25)',  color: COLORS.warn }
    :         { bg: 'rgba(0,230,118,0.15)',   border: 'rgba(0,230,118,0.25)',  color: COLORS.success };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionLabel}>🔐 PANEL DE PERMISOS</Text>
      <View style={styles.grid}>
        {apps.map(app => {
          const bs = getBadgeStyle(app.dangerousPerms);
          return (
            <View key={app.id} style={styles.card}>
              <View style={styles.cardHeader}>
                <View>
                  <Text style={styles.appIcon}>{app.icon}</Text>
                  <Text style={styles.appName}>{app.name}</Text>
                  <Text style={styles.appSub}>{app.dangerousPerms} peligrosos</Text>
                </View>
                <View style={[styles.badge, { backgroundColor: bs.bg, borderColor: bs.border }]}>
                  <Text style={[styles.badgeText, { color: bs.color }]}>{app.dangerousPerms}</Text>
                </View>
              </View>
              <View style={styles.permGrid}>
                {app.allPermissions.map((p, i) => {
                  const btnStyle = p.enabled
                    ? p.category === 'dangerous'
                      ? { bg: 'rgba(255,71,87,0.12)', border: 'rgba(255,71,87,0.3)', color: COLORS.danger }
                      : { bg: 'rgba(0,230,118,0.10)', border: 'rgba(0,230,118,0.25)', color: COLORS.success }
                    : { bg: 'rgba(138,155,181,0.07)', border: 'rgba(138,155,181,0.15)', color: COLORS.textMuted };
                  return (
                    <TouchableOpacity
                      key={i}
                      style={[styles.permBtn, { backgroundColor: btnStyle.bg, borderColor: btnStyle.border }]}
                      onPress={() => onTogglePerm(app.id, p.name)}
                      activeOpacity={0.7}
                    >
                      <Text style={styles.permIcon}>{p.icon}</Text>
                      <Text style={[styles.permState, { color: btnStyle.color }]}>{p.enabled ? 'ON' : 'OFF'}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 12, paddingBottom: 24 },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: COLORS.textSub, letterSpacing: 1, marginBottom: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  card: {
    width: '47.5%',
    backgroundColor: COLORS.card, borderRadius: 16,
    borderWidth: 1, borderColor: COLORS.cardBorder, padding: 12,
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 },
  appIcon: { fontSize: 22, marginBottom: 2 },
  appName: { fontSize: 13, fontWeight: '700', color: COLORS.text },
  appSub: { fontSize: 10, color: COLORS.textSub, marginTop: 1 },
  badge: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  badgeText: { fontSize: 13, fontWeight: '700' },
  permGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 4 },
  permBtn: { borderRadius: 8, borderWidth: 1, padding: 5, alignItems: 'center', width: '30%' },
  permIcon: { fontSize: 14 },
  permState: { fontSize: 9, fontWeight: '700', marginTop: 1 },
});
