// src/data.js

export const COLORS = {
  bg: '#0A0F1C',
  surface: '#111827',
  card: '#1A2235',
  cardBorder: '#1E2D45',
  primary: '#00C6FF',
  primaryDark: '#0072FF',
  danger: '#FF4757',
  warn: '#FFB300',
  success: '#00E676',
  purple: '#B388FF',
  text: '#E8EAED',
  textSub: '#8A9BB5',
  textMuted: '#4A5568',
};

export const INITIAL_APPS = [
  {
    id: 1, name: 'WhatsApp', icon: '💬', size: 285,
    package: 'com.whatsapp', version: '23.20.1', permissions: 8, dangerousPerms: 2, rating: 4.5,
    allPermissions: [
      { name: 'Cámara',        enabled: true,  category: 'dangerous', icon: '📷' },
      { name: 'Micrófono',     enabled: true,  category: 'dangerous', icon: '🎤' },
      { name: 'Contactos',     enabled: true,  category: 'dangerous', icon: '👥' },
      { name: 'Almacenamiento',enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Ubicación',     enabled: false, category: 'dangerous', icon: '📍' },
      { name: 'Galería',       enabled: true,  category: 'normal',    icon: '🖼️' },
      { name: 'Calendario',    enabled: false, category: 'normal',    icon: '📅' },
      { name: 'Internet',      enabled: true,  category: 'normal',    icon: '🌐' },
    ],
  },
  {
    id: 2, name: 'Facebook', icon: '👥', size: 420,
    package: 'com.facebook.katana', version: '430.0', permissions: 15, dangerousPerms: 6, rating: 3.8,
    allPermissions: [
      { name: 'Cámara',        enabled: true,  category: 'dangerous', icon: '📷' },
      { name: 'Micrófono',     enabled: true,  category: 'dangerous', icon: '🎤' },
      { name: 'Ubicación',     enabled: true,  category: 'dangerous', icon: '📍' },
      { name: 'Contactos',     enabled: true,  category: 'dangerous', icon: '👥' },
      { name: 'Almacenamiento',enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Galería',       enabled: true,  category: 'normal',    icon: '🖼️' },
      { name: 'Calendario',    enabled: true,  category: 'normal',    icon: '📅' },
      { name: 'Internet',      enabled: true,  category: 'normal',    icon: '🌐' },
      { name: 'Publicidad',    enabled: true,  category: 'dangerous', icon: '📢' },
      { name: 'Rastreo',       enabled: true,  category: 'dangerous', icon: '👁️' },
      { name: 'Sensores',      enabled: true,  category: 'normal',    icon: '📡' },
      { name: 'Dispositivo',   enabled: true,  category: 'normal',    icon: '📱' },
      { name: 'Datos',         enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Teléfono',      enabled: false, category: 'normal',    icon: '☎️' },
      { name: 'SMS',           enabled: false, category: 'dangerous', icon: '💬' },
    ],
  },
  {
    id: 3, name: 'Gmail', icon: '📧', size: 180,
    package: 'com.google.android.gm', version: '2024.05.01', permissions: 6, dangerousPerms: 1, rating: 4.7,
    allPermissions: [
      { name: 'Almacenamiento',enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Internet',      enabled: true,  category: 'normal',    icon: '🌐' },
      { name: 'Google',        enabled: true,  category: 'normal',    icon: '🔵' },
      { name: 'Calendario',    enabled: false, category: 'normal',    icon: '📅' },
      { name: 'Contactos',     enabled: true,  category: 'normal',    icon: '👥' },
      { name: 'Ubicación',     enabled: false, category: 'dangerous', icon: '📍' },
    ],
  },
  {
    id: 4, name: 'Instagram', icon: '📸', size: 350,
    package: 'com.instagram.android', version: '337.0', permissions: 12, dangerousPerms: 5, rating: 4.2,
    allPermissions: [
      { name: 'Cámara',        enabled: true,  category: 'dangerous', icon: '📷' },
      { name: 'Galería',       enabled: true,  category: 'normal',    icon: '🖼️' },
      { name: 'Micrófono',     enabled: true,  category: 'dangerous', icon: '🎤' },
      { name: 'Ubicación',     enabled: true,  category: 'dangerous', icon: '📍' },
      { name: 'Contactos',     enabled: false, category: 'normal',    icon: '👥' },
      { name: 'Almacenamiento',enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Internet',      enabled: true,  category: 'normal',    icon: '🌐' },
      { name: 'Teléfono',      enabled: false, category: 'dangerous', icon: '☎️' },
      { name: 'Publicidad',    enabled: true,  category: 'dangerous', icon: '📢' },
      { name: 'Dispositivo',   enabled: true,  category: 'normal',    icon: '📱' },
      { name: 'Sensores',      enabled: true,  category: 'normal',    icon: '📡' },
      { name: 'Rastreo',       enabled: true,  category: 'dangerous', icon: '👁️' },
    ],
  },
  {
    id: 5, name: 'Chrome', icon: '🌐', size: 420,
    package: 'com.android.chrome', version: '125.0', permissions: 7, dangerousPerms: 2, rating: 4.6,
    allPermissions: [
      { name: 'Internet',      enabled: true,  category: 'normal',    icon: '🌐' },
      { name: 'Almacenamiento',enabled: true,  category: 'normal',    icon: '💾' },
      { name: 'Ubicación',     enabled: false, category: 'dangerous', icon: '📍' },
      { name: 'Cámara',        enabled: false, category: 'dangerous', icon: '📷' },
      { name: 'Micrófono',     enabled: false, category: 'dangerous', icon: '🎤' },
      { name: 'Contactos',     enabled: false, category: 'normal',    icon: '👥' },
      { name: 'Dispositivo',   enabled: true,  category: 'normal',    icon: '📱' },
    ],
  },
];

export const INITIAL_THREATS = [
  {
    id: 1, app: 'Facebook', type: 'Permisos Excesivos', severity: 'high',
    desc: 'Solicita 6 permisos peligrosos innecesarios para su funcionamiento básico.',
    action: 'Revocar',
  },
  {
    id: 2, app: 'Instagram', type: 'Rastreo de Ubicación', severity: 'high',
    desc: 'Accede a tu ubicación GPS de forma constante en segundo plano.',
    action: 'Deshabilitar',
  },
];
